package com.justanotherprogrammer.mylogin_tutorial.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// import SQLiteOpenHelper to create the database
public class DatabaseHelper extends SQLiteOpenHelper
{
    // define the database name.
    private static final String DATABASE_NAME = "tutorials";

    // define the version of the database.
    private static final int DATABASE_VERSION = 1;

    // Create a default constructor to reference database through the application.
    // use Context as a source that allows access to this java file.
    public DatabaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // define the database table name here :
    public static final String TABLE_NAME = "users";

    // define the table columns here :
    public static final String COL_ID = "id";
    public static final String COL_NAME = "username";
    public static final String COL_PASS = "password";

    // define a create table sql query statement here :
    public static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_NAME + "( "
            + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_NAME + " TEXT, "
            + COL_PASS + " TEXT);";

    @Override
    // This is where the table is created.
    public void onCreate(SQLiteDatabase db)
    {
        // execute the statement query here :
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    // The on upgrade method removes a table every time the database is run. This removes errors, or if the table is altered it add the new changes.
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // reference the table name here :
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Create Database Log In Method here :
    // I used boolean here because i wanted a true or false value so that i would know if a user exists or not.
    public boolean databaseLogIn(String username, String password)
    {
        // create an object (READ_FROM_DATABASE) that will allow you to read the database.
        SQLiteDatabase READ_FROM_DATABASE = getReadableDatabase();

        // set the first array condition to get all the id's in the table.
        String[] data1 = { COL_ID };
        
        // set a query to check the username and passwords in the table.
        String data2 = COL_NAME + "=?" + " and " + COL_PASS + "=?";

        // set an array that will check the users into against the table data.
        String[] data3 = { username, password };

        // use a cursor to set a search point for the data you are looking for.
        // In this case we check the table, which has an if of ?, where data is equal to username=username and password=password.
        Cursor cursor = READ_FROM_DATABASE.query(TABLE_NAME,data1,data2,data3,null,null,null);

        // set a counter for the cursor which should by default equal 2 because of username and password.
        // and by default be greater than zero.
        int count = cursor.getCount();

        // close the cursor.
        cursor.close();

        // then close the database.
        READ_FROM_DATABASE.close();

        // it should return a value greater than 0, if it does not then it will produce an error.
        return count > 0;
    }

    // Create method for Registration here :
    public void databaseRegister(String username, String password)
    {
        // create an object (WRITE_TO_DATABASE) to write to the database.
        SQLiteDatabase WRITE_TO_DATABASE = getWritableDatabase();

        // content values are a form of storage of values which are waiting to be processed.
        ContentValues values = new ContentValues();

        // put that users input values into the relevant column.
        values.put(COL_NAME, username);
        values.put(COL_PASS, password);

        // Insert the values into the table.
        WRITE_TO_DATABASE.insert(TABLE_NAME, null, values);
    }
}
