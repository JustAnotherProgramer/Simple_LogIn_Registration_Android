package com.justanotherprogrammer.mylogin_tutorial.Activities;

import androidx.appcompat.app.AppCompatActivity;

import com.justanotherprogrammer.mylogin_tutorial.Database.DatabaseHelper;
import com.justanotherprogrammer.mylogin_tutorial.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity
{
    // LOGIN TITLE defined here :
    TextView REGISTER_TXT;

    // Input fields to get user input.
    EditText register_User, register_Pass;

    // define the buttons here :
    Button register_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // get the database as an object to utilize here :
        final DatabaseHelper databaseHelper = new DatabaseHelper(this);

        // match the widgets to their XML file id's.
        REGISTER_TXT = findViewById(R.id.Register_title_txt);
        register_User = findViewById(R.id.register_username);
        register_Pass = findViewById(R.id.register_password);
        register_btn = findViewById(R.id.register_btn);

        register_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // these strings allow you to get the users input as a stored sting value.
                String reg_username = register_User.getText().toString().trim();
                String reg_password = register_Pass.getText().toString().trim();

                // this if statement says if both the fields are empty post a toast to say that they cannot be empty.
                if (reg_username.isEmpty() | reg_password.isEmpty())
                {
                    // post instructions or error message here :
                    Toast.makeText(RegisterActivity.this, "Fields cannot be empty!", Toast.LENGTH_SHORT).show();

                }// end of if statement.

                // this else statement says if the first statement is false then all details or criteria have been satisfied.
                // therefore, the logIn is successful.
                else
                {
                    // call the database registration method here :
                    databaseHelper.databaseRegister(reg_username, reg_password);

                    // post instructions or error message here :
                    Toast.makeText(RegisterActivity.this, "Successfully registered", Toast.LENGTH_SHORT).show();

                    // this statement says, if the registration is successful then send the user to the log In screen activity.
                    startActivity(new Intent(RegisterActivity.this, MainActivity.class));

                } // end of else statement.

            }// end of onClick method.

        }); // end of setOnClickListener.

    }// end of onCreate method.

} // end of class.