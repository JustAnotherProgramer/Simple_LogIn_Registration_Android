package com.justanotherprogrammer.mylogin_tutorial.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.justanotherprogrammer.mylogin_tutorial.Database.DatabaseHelper;
import com.justanotherprogrammer.mylogin_tutorial.R;

public class MainActivity extends AppCompatActivity
{
    // define input widgets here :
    EditText USERNAME, PASSWORD;

    // define the Title Text here : (LOGIN)
    TextView Title_LogIn;

    // define buttons here :
    Button Login_btn, makeAccount_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get the database as an object to utilize here :
        final DatabaseHelper databaseHelper = new DatabaseHelper(this);

        // match the widgets to their XML file id's.
        // set title text to be view by user here :
        Title_LogIn = findViewById(R.id.login_title_txt);

        // set fields foe user to type data here :
        USERNAME = findViewById(R.id.login_username);
        PASSWORD = findViewById(R.id.login_password);

        // set the Log In button here :
        Login_btn = findViewById(R.id.login_btn);
        makeAccount_btn = findViewById(R.id.make_account_btn);

        // execute the function for when the user clicks on the button here :
        Login_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // these strings allow you to get the users input as a stored sting value.
                // i Used trim to only get the necessary entered characters, so if there was a space after the user type like : name_ it would only get name.
                String checkUser = USERNAME.getText().toString().trim();
                String checkPass = PASSWORD.getText().toString().trim();

                // set a boolean value (checkInput) to the database logIn method.
                // because the database logIn method ends up returning a true or false value we can set it to another boolean value that we can use.
                // here we use our set value to determine whether to user exists or not and what to do if they are in our database.
                boolean checkInput = databaseHelper.databaseLogIn(checkUser,checkPass);

                // this statement says that if the user exists meaning the value was true, then they should be logged in.
                if (checkInput)
                {
                    // Post a message to tell the user if they did the right thing or where they made an error here :
                    Toast.makeText(MainActivity.this, "Log In Was Successful", Toast.LENGTH_SHORT).show();

                    // allow the user access to the rest of your application here :
                    startActivity(new Intent(MainActivity.this, HomeActivity.class));

                }// end of if statement.

                // this statement says, the user made an error or they do not exist in our database.
                else
                {
                    Toast.makeText(MainActivity.this, "Log In Failed", Toast.LENGTH_SHORT).show();

                }// end of else statement.

            }// end of onClick for LOGIN BUTTON.

        });// end of setOnClickListener for LOGIN BUTTON.

        // execute the function for when the user clicks on the button here :
        makeAccount_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // this function sends the user to make an account if they do not have one.
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));

            }// end of onClick for MAKE ACCOUNT BUTTON.

        });// end of setOnClickListener for MAKE ACCOUNT BUTTON.

    }// end of onCreate Method.

}// end of class.